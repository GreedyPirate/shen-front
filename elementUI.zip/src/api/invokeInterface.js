import ajaxRequest from 'common/js/ajax'

/**
 * 用户登录
 * @param data
 */
export function login(data) {
  return ajaxRequest('/user/login',data);
}

/**
 * 用户注册
 * @param data
 */
export function regist(data) {
  return ajaxRequest('/user/register',data,'put');
}

/**
 * 侧边栏菜单
 */
export function loadSideMenu() {
  return ajaxRequest('/api/menu');
}

/**
 * 发送验证码
 */
export function sendMsg(data) {
  return ajaxRequest('/user/sendMsg',data);
}

/**
 * 侧边栏菜单
 */
export function loadArea() {
  return ajaxRequest('/api/area');
}

/**
 * 上传附件
 */
export function upload() {
  return ajaxRequest('/regist/upload');
}

/**
 * 查询附件
 */
export function getAttachs() {
  return ajaxRequest('/regist/attachments')
}

/**
 * 查询档案信息
 */
export function getArchive() {
  return ajaxRequest('/regist/archives')
}
