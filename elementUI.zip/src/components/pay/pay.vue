<template>
  <div class="pay">
    支付宝支付 ...
    微信支付 ...
    待开发
  </div>
</template>
<script type="text/ecmascript-6">
    export default {}
</script>
<style lang="stylus" rel="stylesheet/stylus">
  .pay
    color #000
</style>
