<template>
  <div class="profile">
    this is your profile!
  </div>
</template>
<script type="text/ecmascript-6">
    export default {}
</script>
<style lang="stylus" rel="stylesheet/stylus">

</style>
