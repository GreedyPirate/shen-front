import axios from 'axios'

/**
 * 使用axios发送ajax请求
 * 如果传一个string参数，默认是get请求，无参数
 * 如果传两个参数
 * @param url
 * @param data
 * @param method
 * @returns {Promise.<TResult>}
 */
export default function ajaxRequest(url, data, method) {
  // 判断一下只传两个参数时，data和method的默认值
  if(arguments.length === 2){ //url,data
    if(arguments[1].indexOf('=') > -1){
      data = arguments[1];
      method = 'post';
    }else if(typeof arguments[1] === 'string'){ //url,method
      method = arguments[1];
      data = '';
    }
  }
  //一个参数默认走get请求
  else if(arguments.length === 1 && typeof arguments[0] === 'string'){
    method = 'get';
    data = {};
  }
  //axios别名发请求
  return axios({
    "url": url,
    "method": method,
    "data":data
  }).then((res) => {
    return Promise.resolve(res.data);
  }).catch((err) => {
    return Promise.reject(err.data);
  })
  ;
}

