export class User{
  constructor({zhName,username,phoneNumber}){
    this.zhName = zhName;
    this.username = username;
    this.phoneNumber = phoneNumber;
  }
}
