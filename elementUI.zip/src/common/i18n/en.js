export const lang = {
  sysName: 'Enterprise Online Registration System',
  plsPhone: 'phone number',
  plsPassword: 'password',
  plsVcode: 'verification code',
  signIn: 'Sign in',
  signUp: 'Sign up',
  tip: 'Don’t have an account?',
  hadAcc: 'Already have an account?',
  submit: 'Account or password can not be empty',
  switchLang: 'switch language',
  sendMsg: 'verification',
  resend: 'resend'
}
