export const lang = {
  pls:'请输入',
  sysName: '在线登记系统',
  plsPhone: '@:lang.pls手机号码',
  plsPassword: '@:lang.pls密码',
  plsVcode: '@:lang.pls验证码',
  signIn: '登录',
  signUp: '注册',
  tip: '没有账号? 去',
  hadAcc: '已有账号? 去',
  submit: '账号密码不能为空',
  switchLang: '切换语言',
  sendMsg: '获取验证码',
  resend: '重新发送'
}
