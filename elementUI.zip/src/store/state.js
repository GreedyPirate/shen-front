export default state = {
  interface:{

  },
  user:{}
}
