export const loginUser = state => state.loginUser;
